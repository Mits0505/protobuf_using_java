package example.simple;

import example.simple.Simple.SimpleMessage;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;

public class SimpleMain {
    public static void main(String[] args) throws IOException {
        System.out.println("Hello World!");

        SimpleMessage.Builder builder = SimpleMessage.newBuilder();

        builder.setId(51)  //set the id field.
                .setIsSimple(true) //set the is_simple field.
                .setName("Simple message for Mitali") //set the name field.
                .addSampleList(1)
                .addSampleList(2)
                .addSampleList(3)
                .addAllSampleList(Arrays.asList(4,5)); //added all the repeated fields.

//          builder.clearSampleList();
//          builder.setSampleList(3,6);
        System.out.println(builder.toString());

        SimpleMessage simpleMessage = builder. build();
        System.out.println("message id: "+simpleMessage.getId());
        System.out.println("message name: "+simpleMessage.getName());

        // Here we are simply writing the message to a file.
        FileOutputStream outputStream = new FileOutputStream("message.txt");
        simpleMessage.writeTo(outputStream);
        outputStream.close();

        /* If you want to send the message over the network, then it can be sent
         *using byte array */

      // byte[] message= simpleMessage.toByteArray();

        FileInputStream inputStream = new FileInputStream("message.txt");
        SimpleMessage messageFromFile = SimpleMessage.parseFrom(inputStream);
        System.out.println();
        System.out.println("message reading from file: ");
        System.out.println(messageFromFile);

    }
}
