package example.simple;

import example.complex.Complex.ComplexMessage;
import example.complex.Complex.DummyMessage;

import java.io.IOException;
import java.util.Arrays;

public class ComplexMain {
    public static void main(String[] args) throws IOException {
        System.out.println("Complex Example");

        DummyMessage oneDummy = newDummyMessage(1, "one dummy message");

        ComplexMessage complexMessage= ComplexMessage.newBuilder()
                                                     .setOneDummy(oneDummy)
                                                     .addMultiDummy(newDummyMessage(2, "two dummy message"))
                                                     .addAllMultiDummy(Arrays.asList(newDummyMessage(3, "three dummy message")
                                                             ,newDummyMessage(4,"four dummy message")))
                                                     .build();
         System.out.println("complex message:");
         System.out.print(complexMessage);

         System.out.println("One Dummy..."+complexMessage.getOneDummy());
         System.out.println("Multi Dummy..."+complexMessage.getMultiDummyList());

    }
    public static DummyMessage newDummyMessage(Integer id, String name){
      return DummyMessage.newBuilder()
              .setId(id)
              .setName(name).build();
    }
}
